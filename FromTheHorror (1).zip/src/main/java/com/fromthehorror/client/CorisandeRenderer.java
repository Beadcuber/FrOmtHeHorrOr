package com.fromthehorror.client;

import com.fromthehorror.CorisandeEntity;
import com.fromthehorror.FromTheHorror;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public class CorisandeRenderer extends MobEntityRenderer<CorisandeEntity, OrbModel> {
    private static final Identifier[] FACES = new Identifier[5];
    static {
        for (int i = 0; i < 5; i++) FACES[i] = new Identifier(FromTheHorror.ID, "textures/entity/corisande_" + i + ".png");
    }

    public CorisandeRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new OrbModel(ctx.getPart(NfLayers.ORB)), 0.3f);
    }

    @Override
    public Identifier getTexture(CorisandeEntity e) {
        return FACES[Math.max(0, Math.min(4, e.getMood()))];
    }

    @Override
    protected void scale(CorisandeEntity e, MatrixStack m, float amount) {
        float s = e.isHostile() ? 2.6f : 1.3f;
        m.scale(s, s, s);
    }

    @Override
    protected int getBlockLight(CorisandeEntity e, BlockPos pos) { return 15; }
}
