package com.fromthehorror.client;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;

/** Eyes that stay bright in the dark, like a spider's or an enderman's. */
public class GlowEyes<T extends Entity, M extends EntityModel<T>> extends EyesFeatureRenderer<T, M> {
    private final RenderLayer layer;

    public GlowEyes(FeatureRendererContext<T, M> ctx, Identifier texture) {
        super(ctx);
        this.layer = RenderLayer.getEyes(texture);
    }

    @Override
    public RenderLayer getEyesTexture() { return layer; }
}
