package com.fromthehorror.mixin;

import com.fromthehorror.client.FogState;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Permanent thick fog in the Overworld, thicker at night and when the Man from the Fog is close. */
@Mixin(BackgroundRenderer.class)
public abstract class FogMixin {
    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void fth$fog(Camera camera, BackgroundRenderer.FogType fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        if (fogType != BackgroundRenderer.FogType.FOG_TERRAIN || camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null || w.getRegistryKey() != World.OVERWORLD) return;
        float l = Math.max(0.0f, Math.min(1.0f, w.getSkyBrightness(tickDelta)));
        float end = Math.min(viewDistance, (24.0f + 34.0f * l) * FogState.density);
        RenderSystem.setShaderFogStart(end * 0.06f);
        RenderSystem.setShaderFogEnd(end);
        float k = 0.10f + 0.90f * l;
        RenderSystem.setShaderFogColor(0.66f * k, 0.70f * k, 0.74f * k);
    }
}
