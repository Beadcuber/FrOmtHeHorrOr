package com.fromthehorror;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.util.Identifier;

import java.util.Locale;

public class FromTheHorror implements ModInitializer {
    public static final String ID = "fromthehorror";
    public static EntityType<DwellerEntity> DWELLER;
    public static EntityType<WatcherEntity> WATCHER;
    public static EntityType<ManFromTheFogEntity> MAN;
    public static EntityType<CorisandeEntity> CORISANDE;
    public static Item FLASHLIGHT;

    private static Item egg(String name, EntityType<? extends MobEntity> type, int a, int b) {
        return Registry.register(Registries.ITEM, new Identifier(ID, name + "_spawn_egg"),
                new SpawnEggItem(type, a, b, new FabricItemSettings()));
    }

    @Override
    public void onInitialize() {
        DWELLER = Registry.register(Registries.ENTITY_TYPE, new Identifier(ID, "dweller"),
                FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, DwellerEntity::new)
                        .dimensions(EntityDimensions.fixed(0.7f, 2.4f)).trackRangeBlocks(64).build());
        WATCHER = Registry.register(Registries.ENTITY_TYPE, new Identifier(ID, "watcher"),
                FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, WatcherEntity::new)
                        .dimensions(EntityDimensions.fixed(0.6f, 2.3f)).trackRangeBlocks(96).build());
        MAN = Registry.register(Registries.ENTITY_TYPE, new Identifier(ID, "man_from_the_fog"),
                FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ManFromTheFogEntity::new)
                        .dimensions(EntityDimensions.fixed(0.7f, 2.5f)).trackRangeBlocks(80).build());
        CORISANDE = Registry.register(Registries.ENTITY_TYPE, new Identifier(ID, "corisande"),
                FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, CorisandeEntity::new)
                        .dimensions(EntityDimensions.fixed(0.7f, 0.7f)).trackRangeBlocks(80).build());
        FabricDefaultAttributeRegistry.register(DWELLER, DwellerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(WATCHER, WatcherEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MAN, ManFromTheFogEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(CORISANDE, CorisandeEntity.createAttributes());

        FLASHLIGHT = Registry.register(Registries.ITEM, new Identifier(ID, "flashlight"),
                new FlashlightItem(new FabricItemSettings().maxCount(1).maxDamage(1200)));
        Item e1 = egg("dweller", DWELLER, 0x1a1a1a, 0x969089);
        Item e2 = egg("watcher", WATCHER, 0x0a0a0c, 0xffffff);
        Item e3 = egg("man_from_the_fog", MAN, 0x101010, 0xe6e6e6);
        Item e4 = egg("corisande", CORISANDE, 0xff9628, 0x7a1010);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(FLASHLIGHT));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> { e.add(e1); e.add(e2); e.add(e3); e.add(e4); });

        ServerTickEvents.END_WORLD_TICK.register(DreadDirector::tick);

        // Corisande hears every chat message. Starting with her name makes her answer anything.
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String raw = message.getContent().getString();
            String low = raw.toLowerCase(Locale.ROOT).trim();
            boolean addressed = low.startsWith("corisande") || low.startsWith("cori ") || low.startsWith("cori,") || low.equals("cori");
            sender.getServer().execute(() -> CorisandeManager.chat(sender, raw, addressed));
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> {
            dispatcher.register(CommandManager.literal("horror")
                .requires(s -> s.hasPermissionLevel(2))
                .then(CommandManager.literal("spawn")
                    .then(CommandManager.literal("dweller").executes(c -> {
                        DreadDirector.spawn(c.getSource().getWorld(), c.getSource().getPlayerOrThrow(), DWELLER, 10, 14); return 1; }))
                    .then(CommandManager.literal("watcher").executes(c -> {
                        DreadDirector.spawn(c.getSource().getWorld(), c.getSource().getPlayerOrThrow(), WATCHER, 20, 26); return 1; }))
                    .then(CommandManager.literal("man").executes(c -> {
                        DreadDirector.spawn(c.getSource().getWorld(), c.getSource().getPlayerOrThrow(), MAN, 12, 16); return 1; }))
                    .then(CommandManager.literal("man_from_the_fog").executes(c -> {
                        DreadDirector.spawn(c.getSource().getWorld(), c.getSource().getPlayerOrThrow(), MAN, 12, 16); return 1; })))
                .then(CommandManager.literal("event").executes(c -> {
                    DreadDirector.trigger(c.getSource().getWorld(), c.getSource().getPlayerOrThrow()); return 1; }))
                .then(CommandManager.literal("corisande")
                    .then(CommandManager.literal("turn").executes(c -> {
                        CorisandeManager.turnNow(c.getSource().getWorld()); return 1; }))
                    .then(CommandManager.literal("reset").executes(c -> {
                        CorisandeManager.reset(c.getSource().getWorld()); return 1; }))));
            dispatcher.register(CommandManager.literal("corisande")
                .then(CommandManager.literal("summon").executes(c -> {
                    CorisandeManager.summon(c.getSource().getPlayerOrThrow()); return 1; }))
                .then(CommandManager.argument("message", StringArgumentType.greedyString()).executes(c -> {
                    CorisandeManager.chat(c.getSource().getPlayerOrThrow(), StringArgumentType.getString(c, "message"), true); return 1; })));
        });
    }
}
