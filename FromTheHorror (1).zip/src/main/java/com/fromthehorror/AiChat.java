package com.fromthehorror;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** Optional language-model brain. Only used when config/fromthehorror.json has an apiKey. */
public final class AiChat {
    private AiChat() {}

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final Map<UUID, List<String[]>> HISTORY = new HashMap<>();

    public static boolean enabled() { return !Config.get().apiKey.isBlank(); }

    /** Calls back on the server thread with her reply, or null if the call failed. */
    public static void ask(ServerPlayerEntity p, String msg, String system, Consumer<String> done) {
        final MinecraftServer server = p.getServer();
        final UUID id = p.getUuid();
        final List<String[]> hist = HISTORY.computeIfAbsent(id, k -> new ArrayList<>());
        final Config cfg = Config.get();

        JsonArray msgs = new JsonArray();
        for (String[] m : hist) {
            JsonObject o = new JsonObject();
            o.addProperty("role", m[0]);
            o.addProperty("content", m[1]);
            msgs.add(o);
        }
        JsonObject u = new JsonObject();
        u.addProperty("role", "user");
        u.addProperty("content", msg);
        msgs.add(u);

        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("max_tokens", 160);
        body.addProperty("system", system);
        body.add("messages", msgs);

        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(cfg.endpoint))
                    .timeout(Duration.ofSeconds(20))
                    .header("content-type", "application/json")
                    .header("x-api-key", cfg.apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();
            HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenAccept(resp -> {
                String out = null;
                try {
                    if (resp.statusCode() == 200) {
                        JsonObject j = JsonParser.parseString(resp.body()).getAsJsonObject();
                        out = j.getAsJsonArray("content").get(0).getAsJsonObject().get("text").getAsString();
                        out = out.replace('\n', ' ').replace('*', ' ').trim();
                        if (out.length() > 260) out = out.substring(0, 260);
                    }
                } catch (Exception ignored) {
                    out = null;
                }
                final String reply = (out == null || out.isEmpty()) ? null : out;
                server.execute(() -> {
                    if (reply != null) {
                        hist.add(new String[] { "user", msg });
                        hist.add(new String[] { "assistant", reply });
                        while (hist.size() > 8) { hist.remove(0); hist.remove(0); }
                    }
                    done.accept(reply);
                });
            }).exceptionally(t -> {
                server.execute(() -> done.accept(null));
                return null;
            });
        } catch (Exception e) {
            done.accept(null);
        }
    }
}
