package com.fromthehorror.mixin;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Turns the Overworld sky grey so it blends into the fog instead of showing a hard edge. */
@Mixin(ClientWorld.class)
public abstract class SkyMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void fth$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        ClientWorld self = (ClientWorld) (Object) this;
        if (self.getRegistryKey() != World.OVERWORLD) return;
        Vec3d c = cir.getReturnValue();
        float l = Math.max(0.0f, Math.min(1.0f, self.getSkyBrightness(tickDelta)));
        float k = 0.10f + 0.90f * l;
        double r = c.x + (0.66 * k - c.x) * 0.85;
        double g = c.y + (0.70 * k - c.y) * 0.85;
        double b = c.z + (0.74 * k - c.z) * 0.85;
        cir.setReturnValue(new Vec3d(r, g, b));
    }
}
