package com.fromthehorror;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

import java.util.UUID;

/** Saved per world: Corisande's anger, the 14-day countdown, and whether she has turned. */
public class CorisandeState extends PersistentState {
    public boolean met, turned, dead, warned, greeted;
    public long madDay;
    public int anger;
    public double greed;
    public UUID entity;
    public String nick;

    public static CorisandeState get(ServerWorld w) {
        ServerWorld ow = w.getServer().getOverworld();
        return ow.getPersistentStateManager().getOrCreate(CorisandeState::fromNbt, CorisandeState::new, "fromthehorror_corisande");
    }

    @Override
    public NbtCompound writeNbt(NbtCompound n) {
        n.putBoolean("met", met); n.putBoolean("turned", turned); n.putBoolean("dead", dead);
        n.putBoolean("warned", warned); n.putBoolean("greeted", greeted);
        n.putLong("madDay", madDay); n.putInt("anger", anger); n.putDouble("greed", greed);
        if (entity != null) n.putUuid("entity", entity);
        if (nick != null) n.putString("nick", nick);
        return n;
    }

    public static CorisandeState fromNbt(NbtCompound n) {
        CorisandeState s = new CorisandeState();
        s.met = n.getBoolean("met"); s.turned = n.getBoolean("turned"); s.dead = n.getBoolean("dead");
        s.warned = n.getBoolean("warned"); s.greeted = n.getBoolean("greeted");
        s.madDay = n.getLong("madDay"); s.anger = n.getInt("anger"); s.greed = n.getDouble("greed");
        if (n.containsUuid("entity")) s.entity = n.getUuid("entity");
        if (n.contains("nick")) s.nick = n.getString("nick");
        return s;
    }
}
