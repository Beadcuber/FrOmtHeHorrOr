package com.fromthehorror.client;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Zero-setup text-to-speech using the voice your operating system already has. */
public final class Tts {
    private Tts() {}

    private static volatile boolean speaking = false;
    private static volatile long lastEnd = 0;

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "fromthehorror-tts");
        t.setDaemon(true);
        return t;
    });

    /** True while she is talking (and for a moment after), so the microphone ignores her own voice. */
    public static boolean isSpeaking() {
        return speaking || System.currentTimeMillis() - lastEnd < 1500;
    }

    public static void speak(String text) { speak(text, false); }

    public static void speak(String text, boolean evil) {
        final String clean = text.replaceAll("[^A-Za-z0-9 .,!?-]", "");
        if (clean.isBlank()) return;
        POOL.submit(() -> {
            String os = System.getProperty("os.name", "").toLowerCase();
            speaking = true;
            try {
                ProcessBuilder pb;
                if (os.contains("win")) {
                    pb = new ProcessBuilder("powershell", "-NoProfile", "-Command",
                            "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Rate = " + (evil ? -4 : -1) + "; $s.Speak('" + clean + "')");
                } else if (os.contains("mac")) {
                    pb = evil ? new ProcessBuilder("say", "-r", "110", clean) : new ProcessBuilder("say", clean);
                } else {
                    pb = evil ? new ProcessBuilder("espeak", "-p", "10", "-s", "110", clean) : new ProcessBuilder("espeak", clean);
                }
                pb.redirectErrorStream(true);
                Process p = pb.start();
                p.getInputStream().readAllBytes();
                p.waitFor();
            } catch (Exception ignored) {
                // No voice available: the chat text still shows.
            } finally {
                speaking = false;
                lastEnd = System.currentTimeMillis();
            }
        });
    }
}
