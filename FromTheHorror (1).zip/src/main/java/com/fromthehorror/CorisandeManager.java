package com.fromthehorror;

import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Random;

/** Spawns Corisande, handles anger, the 14-day countdown, gifts, and chat. */
public final class CorisandeManager {
    private CorisandeManager() {}
    public static final int REALLY_MAD = 70;
    private static final Random R = new Random();
    private static int idle = 240;
    private static int seconds = 0;
    private static long warnAt = 0;
    private static long careAt = 0;
    private static long spawnedAt = -1000;
    private static long provokedAt = -1000;

    private static final String[][] IDLE = {
        { "Isn't it nice out here? Just us.", "Want to build something together?", "I'm glad you're here. You can ask me for things, you know." },
        { "I can feel you getting upset with me.", "Did you hear that? ...Never mind.", "You'd tell me if you were leaving, right?" },
        { "Something is almost here.", "I can hear everything now.", "Don't look at me like that yet." }
    };

    public static void say(ServerPlayerEntity p, String line, boolean evil) {
        p.sendMessage(Text.literal("<Corisande> " + line).formatted(evil ? Formatting.DARK_RED : Formatting.GOLD), false);
    }

    /** Adds anger. Returns the 14-day line if she just became really mad, else null. */
    public static String bump(ServerPlayerEntity p, CorisandeState st, int amt, String reason) {
        if (st.turned || st.dead) return null;
        st.anger = Math.min(100, st.anger + amt);
        st.markDirty();
        if (st.anger >= REALLY_MAD && !st.warned) return prophecy(p, st, reason);
        return null;
    }

    /** The 14-day line. Starts the countdown from today, whatever day it is. */
    public static String prophecy(ServerPlayerEntity p, CorisandeState st, String reason) {
        ServerWorld w = p.getServerWorld();
        st.warned = true;
        st.anger = 100;
        st.madDay = w.getTimeOfDay() / 24000L;
        st.markDirty();
        return "Something is coming in 14 days, " + p.getName().getString() + ". " + reason;
    }

    public static void chat(ServerPlayerEntity sender, String raw, boolean addressed) {
        ServerWorld w = sender.getServerWorld();
        CorisandeState st = CorisandeState.get(w);
        if (st.dead) return;
        String msg = addressed ? raw.trim().replaceFirst("(?i)^(corisande|cori)[\\s,:!.-]*", "") : raw.trim();
        Entity e = st.entity == null ? null : w.getEntity(st.entity);
        CorisandeEntity c = e instanceof CorisandeEntity ce ? ce : null;
        String reply = CorisandeBrain.reply(sender, msg.isEmpty() ? "hello" : msg, st, c, w, addressed);
        boolean wantsAi = CorisandeBrain.fallback && addressed && AiChat.enabled() && !msg.isEmpty();
        st.markDirty();
        if (wantsAi) {
            final String backup = reply;
            AiChat.ask(sender, msg, systemPrompt(sender, st, w), r -> {
                CorisandeState now = CorisandeState.get(w);
                say(sender, r != null ? r : backup, now.turned || now.warned);
            });
            return;
        }
        if (reply != null) say(sender, reply, st.turned || st.warned);
    }

    private static String systemPrompt(ServerPlayerEntity p, CorisandeState st, ServerWorld w) {
        long day = w.getTimeOfDay() / 24000L;
        long left = st.warned ? Math.max(0, st.madDay + 14 - day) : 14;
        String mood;
        if (st.turned) mood = "You have turned into a monster with 100 health and you are hunting the player. Be cold, taunting and brief.";
        else if (st.warned) mood = "You are furious and have told the player something is coming in 14 days. About " + left + " days remain. Be cold and menacing, hint at what you will do.";
        else if (st.anger >= 35) mood = "You are hurt and getting angry. Be short, passive-aggressive and a little ominous.";
        else mood = "You are warm, curious and helpful, with an undercurrent of loneliness. Share real Minecraft knowledge when asked.";
        String name = st.nick != null ? st.nick : p.getName().getString();
        return "You are Corisande, a small glowing orange orb that floats beside the player in a Minecraft horror world. "
                + "Reply with one or two short sentences of plain text. No markdown, no emojis, never break character. "
                + "The game itself handles giving items, so never claim to hand over items. "
                + mood + " The player is called " + name + ". It is " + (w.isNight() ? "night" : "day") + " on day " + (day + 1)
                + ". Their health is " + (int) Math.ceil(p.getHealth()) + " out of 20 and their hunger is " + p.getHungerManager().getFoodLevel() + " out of 20.";
    }

    public static void provoke(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        if (w.getTime() - provokedAt < 40) return;
        provokedAt = w.getTime();
        CorisandeState st = CorisandeState.get(w);
        String pr = bump(p, st, 30, "You shouldn't have hit me.");
        say(p, pr != null ? pr : "Ow. Don't do that again.", false);
    }

    public static void summon(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        CorisandeState st = CorisandeState.get(w);
        if (st.dead) { say(p, "...", true); return; }
        st.met = true;
        spawnNear(w, p, st);
    }

    public static void turnNow(ServerWorld w) {
        CorisandeState st = CorisandeState.get(w);
        if (st.turned || st.dead) return;
        st.turned = true;
        st.warned = true;
        st.markDirty();
        for (ServerPlayerEntity pl : w.getPlayers()) {
            say(pl, "Fourteen days. I told you something was coming.", true);
            say(pl, "It was me.", true);
            w.playSound(null, pl.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 0.6f, 0.5f);
        }
    }

    public static void reset(ServerWorld w) {
        CorisandeState st = CorisandeState.get(w);
        st.met = false; st.turned = false; st.dead = false; st.warned = false; st.greeted = false;
        st.anger = 0; st.greed = 0; st.madDay = 0; st.entity = null;
        st.markDirty();
    }

    private static void spawnNear(ServerWorld w, ServerPlayerEntity p, CorisandeState st) {
        BlockPos pos = DreadDirector.findSpot(w, p, 2, 4);
        if (pos == null) pos = p.getBlockPos();
        CorisandeEntity e = FromTheHorror.CORISANDE.create(w);
        if (e == null) return;
        e.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5, p.getYaw(), 0f);
        if (st.turned) e.turn();
        w.spawnEntity(e);
        st.entity = e.getUuid();
        spawnedAt = w.getTime();
        if (!st.greeted) {
            st.greeted = true;
            say(p, "Hi! I'm Corisande. I'm a little light, and I'll stay with you.", false);
            say(p, "Just talk in chat. Ask me for items if you need something. Don't ask for too much.", false);
        }
        st.markDirty();
    }

    private static int moodFor(CorisandeState st) {
        if (st.turned) return 4;
        if (st.warned) return 3;
        if (st.anger >= 55) return 3;
        if (st.anger >= 35) return 2;
        if (st.anger >= 15) return 1;
        return 0;
    }

    /** Called once a second in the Overworld. */
    public static void tick(ServerWorld w) {
        List<ServerPlayerEntity> players = w.getPlayers();
        if (players.isEmpty()) return;
        ServerPlayerEntity p = players.get(0);
        CorisandeState st = CorisandeState.get(w);
        long day = w.getTimeOfDay() / 24000L;
        seconds++;
        if (!st.met) { st.met = true; st.markDirty(); }
        if (st.dead) return;

        if (st.greed > 0) st.greed = Math.max(0, st.greed - 0.25);
        if (!st.warned && st.anger > 0 && seconds % 6 == 0) st.anger--;
        if (st.warned && !st.turned && day >= st.madDay + 14) turnNow(w);

        Entity e = st.entity == null ? null : w.getEntity(st.entity);
        if ((e == null || e.isRemoved()) && w.getTime() - spawnedAt > 200) spawnNear(w, p, st);
        if (e instanceof CorisandeEntity ce) ce.setMood(moodFor(st));

        if (!st.turned) {
            long now = w.getTime();
            if (now > careAt) {
                if (p.getHealth() < 7.0f) { careAt = now + 2400; say(p, "You're badly hurt. Eat something and get somewhere safe.", st.warned); }
                else if (p.getHungerManager().getFoodLevel() < 6) { careAt = now + 2400; say(p, "Your stomach is growling. You need food.", st.warned); }
            }
            if (now > warnAt && !w.getEntitiesByClass(DwellerEntity.class, p.getBoundingBox().expand(30), x -> true).isEmpty()) {
                warnAt = now + 600;
                say(p, "Don't turn around. Something is following us. Keep your light on it.", false);
            } else if (--idle <= 0) {
                idle = 240 + R.nextInt(180);
                int stage = st.warned ? 2 : st.anger >= 35 ? 1 : 0;
                String[] a = IDLE[stage];
                say(p, a[R.nextInt(a.length)], false);
            }
        }
    }
}
