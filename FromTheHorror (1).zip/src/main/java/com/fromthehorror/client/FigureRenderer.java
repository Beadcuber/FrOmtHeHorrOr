package com.fromthehorror.client;

import com.fromthehorror.FromTheHorror;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.Identifier;

public class FigureRenderer<T extends HostileEntity> extends MobEntityRenderer<T, FigureModel<T>> {
    private final Identifier texture;
    private final float scale;

    public FigureRenderer(EntityRendererFactory.Context ctx, EntityModelLayer layer, FigureModel.Spec spec, String tex, float scale) {
        super(ctx, new FigureModel<>(ctx.getPart(layer), spec), 0.5f);
        this.texture = new Identifier(FromTheHorror.ID, "textures/entity/" + tex + ".png");
        this.scale = scale;
        this.addFeature(new GlowEyes<T, FigureModel<T>>(this, new Identifier(FromTheHorror.ID, "textures/entity/" + tex + "_eyes.png")));
    }

    @Override
    public Identifier getTexture(T entity) { return texture; }

    @Override
    protected void scale(T entity, MatrixStack matrices, float amount) {
        matrices.scale(scale, scale, scale);
    }
}
