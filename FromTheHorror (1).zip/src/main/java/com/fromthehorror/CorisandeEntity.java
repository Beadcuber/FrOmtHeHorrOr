package com.fromthehorror;

import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/** Corisande: a little orange orb that hovers with you. Her face shows her mood. After her countdown she becomes a monster. */
public class CorisandeEntity extends PathAwareEntity {
    private static final TrackedData<Boolean> HOSTILE = DataTracker.registerData(CorisandeEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final TrackedData<Integer> MOOD = DataTracker.registerData(CorisandeEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public boolean stay = false;

    public CorisandeEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 20, true);
        this.setNoGravity(true);
        this.setPersistent();
        this.setCustomName(Text.literal("Corisande"));
        this.setCustomNameVisible(true);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.5)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 8.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        BirdNavigation nav = new BirdNavigation(this, world);
        nav.setCanPathThroughDoors(false);
        nav.setCanSwim(true);
        nav.setCanEnterOpenDoors(true);
        return nav;
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(HOSTILE, false);
        this.dataTracker.startTracking(MOOD, 0);
    }

    public boolean isHostile() { return this.dataTracker.get(HOSTILE); }
    public int getMood() { return this.dataTracker.get(MOOD); }
    public void setMood(int m) { if (getMood() != m) this.dataTracker.set(MOOD, m); }

    @Override
    public EntityDimensions getDimensions(EntityPose pose) {
        return isHostile() ? EntityDimensions.fixed(1.6f, 1.8f) : super.getDimensions(pose);
    }

    /** Become the monster: 100 health (50 hearts). */
    public void turn() {
        this.dataTracker.set(HOSTILE, true);
        this.dataTracker.set(MOOD, 4);
        this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(100.0);
        this.getAttributeInstance(EntityAttributes.GENERIC_FLYING_SPEED).setBaseValue(0.75);
        this.setHealth(100.0f);
        this.calculateDimensions();
    }

    @Override
    public void tick() {
        super.tick();
        World w = this.getWorld();
        if (w.isClient) return;
        ServerWorld sw = (ServerWorld) w;
        if (this.age % 8 == 0) {
            sw.spawnParticles(isHostile() ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.END_ROD, getX(), getY() + 0.5, getZ(), 1, 0.2, 0.2, 0.2, 0.01);
        }
        if (this.age % 20 == 0) {
            CorisandeState st = CorisandeState.get(sw);
            if (st.entity != null && !st.entity.equals(this.getUuid()) && this.age > 40) { this.discard(); return; }
            if (st.turned && !isHostile()) turn();
        }
        PlayerEntity p = w.getClosestPlayer(this, 64.0);
        if (p == null || p.isSpectator()) return;
        double d = this.distanceTo(p);
        if (isHostile()) {
            this.getNavigation().startMovingTo(p.getX(), p.getY() + 0.8, p.getZ(), 1.4);
            if (d < 3.2 && this.age % 15 == 0) this.tryAttack(p);
            if (this.age % 50 == 0 && d < 30) {
                w.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.HOSTILE, 1.0f, 0.8f);
            }
        } else {
            this.getLookControl().lookAt(p, 30f, 30f);
            if (d > 28) {
                this.requestTeleport(p.getX() + 1.5, p.getY() + 1.5, p.getZ() + 1.5);
            } else if (!stay && d > 4) {
                this.getNavigation().startMovingTo(p.getX(), p.getY() + 1.5, p.getZ(), 1.0);
            } else {
                this.getNavigation().stop();
            }
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (isHostile()) return super.damage(source, amount);
        if (!this.getWorld().isClient && source.getAttacker() instanceof ServerPlayerEntity sp) {
            CorisandeManager.provoke(sp);
        }
        return source.isOf(DamageTypes.OUT_OF_WORLD) ? super.damage(source, amount) : false;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (this.getWorld() instanceof ServerWorld sw) {
            CorisandeState st = CorisandeState.get(sw);
            st.dead = true;
            st.markDirty();
            for (ServerPlayerEntity pl : sw.getPlayers()) {
                CorisandeManager.say(pl, "...you really did it. The quiet is a relief.", true);
            }
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Hostile", isHostile());
        nbt.putBoolean("Stay", stay);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        stay = nbt.getBoolean("Stay");
        if (nbt.getBoolean("Hostile")) turn();
    }
}
