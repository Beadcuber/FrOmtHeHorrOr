package com.fromthehorror.client;

import com.fromthehorror.CorisandeEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

/** Corisande: a glowing orb with a face and a little flame on top. When she turns she grows spikes and long arms. */
public class OrbModel extends EntityModel<CorisandeEntity> {
    private final ModelPart root, body, spikes, rArm, lArm, tuft;

    public OrbModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.tuft = body.getChild("tuft");
        this.spikes = body.getChild("spikes");
        this.rArm = body.getChild("right_arm");
        this.lArm = body.getChild("left_arm");
    }

    public static TexturedModelData build() { return Layers.orb(); }

    @Override
    public void setAngles(CorisandeEntity e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        boolean evil = e.isHostile();
        spikes.visible = evil;
        rArm.visible = evil;
        lArm.visible = evil;
        tuft.visible = !evil;
        body.pivotY = 16 + MathHelper.sin(anim * 0.1f) * 1.5f;
        body.yaw = headYaw * 0.017453292f;
        body.pitch = headPitch * 0.017453292f;
        tuft.roll = MathHelper.sin(anim * 0.25f) * 0.12f;
        float sw = MathHelper.sin(anim * 0.15f) * 0.4f;
        rArm.pitch = sw;
        lArm.pitch = -sw;
        rArm.roll = 0.15f;
        lArm.roll = -0.15f;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float r, float g, float b, float a) {
        root.render(matrices, vertices, light, overlay, r, g, b, a);
    }
}
