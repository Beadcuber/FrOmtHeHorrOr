package com.fromthehorror.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Lets Corisande hear your microphone using Windows' built-in speech recognition. Off until you run /corilisten on. */
public final class VoiceListener {
    private VoiceListener() {}

    private static Process proc;
    private static boolean hookAdded = false;

    private static final String SCRIPT = """
        $ErrorActionPreference = 'Stop'
        try {
          Add-Type -AssemblyName System.Speech
          $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine
          $engine.SetInputToDefaultAudioDevice()
          $engine.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
          Register-ObjectEvent -InputObject $engine -EventName SpeechRecognized -Action {
            $r = $Event.SourceEventArgs.Result
            if ($r.Confidence -gt 0.45) { [Console]::Out.WriteLine('HEARD:' + $r.Text); [Console]::Out.Flush() }
          } | Out-Null
          $engine.RecognizeAsync([System.Speech.Recognition.RecognizeMode]::Multiple)
          [Console]::Out.WriteLine('READY'); [Console]::Out.Flush()
          while ($true) { Start-Sleep -Seconds 1 }
        } catch { [Console]::Out.WriteLine('ERROR:' + $_.Exception.Message); [Console]::Out.Flush() }
        """;

    public static boolean isOn() { return proc != null && proc.isAlive(); }

    private static void info(MinecraftClient mc, String msg) {
        mc.execute(() -> { if (mc.player != null) mc.player.sendMessage(Text.literal("[Voice] " + msg).formatted(Formatting.GRAY), false); });
    }

    public static void start(MinecraftClient mc, boolean quiet) {
        if (isOn()) { if (!quiet) info(mc, "Already listening."); return; }
        if (!System.getProperty("os.name", "").toLowerCase().contains("win")) {
            if (!quiet) info(mc, "Voice listening only works on Windows. You can still type to Corisande.");
            return;
        }
        try {
            Path script = Files.createTempFile("corisande-listen", ".ps1");
            Files.writeString(script, SCRIPT, StandardCharsets.UTF_8);
            script.toFile().deleteOnExit();
            ProcessBuilder pb = new ProcessBuilder("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script.toString());
            pb.redirectError(ProcessBuilder.Redirect.DISCARD);
            proc = pb.start();
            if (!hookAdded) {
                hookAdded = true;
                Runtime.getRuntime().addShutdownHook(new Thread(VoiceListener::stop));
            }
            final Process mine = proc;
            Thread t = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(mine.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        if (line.startsWith("READY")) info(mc, "Corisande is listening. Just talk. (/corilisten off to stop)");
                        else if (line.startsWith("ERROR:")) info(mc, "Microphone or speech recognition unavailable: " + line.substring(6));
                        else if (line.startsWith("HEARD:")) {
                            String text = line.substring(6).replaceAll("[^A-Za-z0-9 .,!?'-]", "").trim();
                            if (text.isEmpty() || Tts.isSpeaking()) continue;
                            mc.execute(() -> {
                                if (mc.player != null) mc.player.networkHandler.sendChatCommand("corisande " + text);
                            });
                        }
                    }
                } catch (Exception ignored) {
                }
            }, "fromthehorror-voice");
            t.setDaemon(true);
            t.start();
        } catch (Exception e) {
            info(mc, "Could not start voice listening: " + e.getMessage());
        }
    }

    public static void stop() {
        if (proc != null) {
            proc.destroyForcibly();
            proc = null;
        }
    }
}
