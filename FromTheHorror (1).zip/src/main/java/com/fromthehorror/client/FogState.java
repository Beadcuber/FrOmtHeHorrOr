package com.fromthehorror.client;

import com.fromthehorror.ManFromTheFogEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

/** How thick the always-on fog is right now. It closes in when the Man from the Fog is near. */
public final class FogState {
    private FogState() {}

    /** 1.0 = normal fog, lower = thicker. */
    public static float density = 1.0f;
    private static float target = 1.0f;

    public static void tick(MinecraftClient c) {
        if (c.world == null || c.player == null) { density = 1.0f; target = 1.0f; return; }
        if (c.world.getTime() % 10 == 0) {
            boolean near = false;
            for (Entity e : c.world.getEntities()) {
                if (e instanceof ManFromTheFogEntity && e.squaredDistanceTo(c.player) < 48.0 * 48.0) { near = true; break; }
            }
            target = near ? 0.55f : 1.0f;
        }
        density += (target - density) * 0.03f;
    }
}
