# FromTheHorror (Fabric 1.20.1)

## Build with GitHub
Push this folder to a repo. The Actions workflow builds the mod. Download the artifact **FromTheHorror**; it contains ONE jar, `FromTheHorror-1.1.0.jar`.
Put that jar in your `mods` folder together with **Fabric Loader 0.15+** and **Fabric API 0.92.2+1.20.1** (Minecraft 1.20.1).
This is a Fabric mod. It will not load on Forge/NeoForge or other Minecraft versions.

## What is in it
- Permanent thick grey fog in the Overworld (denser at night, closes in when the Man from the Fog is near) with a matching grey sky.
- **Man from the Fog**: tall pale figure in a suit and hat. Appears out of the fog, day or night. Light makes him back away.
- **The Dweller** (caves, only moves when you look away), **The Watcher** (night, glowing white eyes).
- Flashlight: glass pane / iron ingot / redstone in a column. Right click toggles. Repair at an anvil with redstone.
- Spawn eggs for all four mobs.

## Corisande
- Spawns next to you at the start of the game as a little orange orb.
- Just type in chat to ask for items ("give me 5 iron ingots", "i need a diamond"). Start a message with "corisande" to talk to her.
- Common items are free. Rare ones cost patience. Ask for too much too fast and she says: "Something is coming in 14 days."
- Insult or hit her until she is really mad and she says the same line. This works on any day.
- 14 Minecraft days later she turns into a monster with 100 health (50 hearts).
- Her face changes with her mood, from happy to furious. She remembers your name ("call me Sam").
- She speaks her replies aloud (`/corivoice off` to mute).
- She hears your microphone on Windows as soon as you join a world (`/corilisten off` to stop). Voice input needs Windows speech recognition.

### Optional: make her smarter with a language model
Run the game once, then open `config/fromthehorror.json` and paste an Anthropic API key into `apiKey`. With a key, anything her built-in rules cannot answer goes to the model (she stays in character). Without a key she uses her built-in brain only.

## Commands
`/horror spawn dweller|watcher|man`, `/horror event`, `/horror corisande turn|reset` (operators), `/corisande summon`, `/corisande <message>`.
