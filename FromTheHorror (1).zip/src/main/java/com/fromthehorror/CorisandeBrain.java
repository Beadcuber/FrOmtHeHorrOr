package com.fromthehorror;

import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Corisande's mind: gifts, moods, and awareness of the world. Returns null when she should stay quiet. */
public final class CorisandeBrain {
    private CorisandeBrain() {}
    private static final Random R = new Random();
    /** Set when no rule matched, so the optional language model can answer instead. */
    public static boolean fallback = false;
    private static final Pattern NAME = Pattern.compile("(?:my name is|call me|i am called|i'm called) ([a-z0-9_]{2,16})");
    private static final Pattern MATH = Pattern.compile("(-?\\d+(?:\\.\\d+)?)\\s*([+\\-*/x])\\s*(-?\\d+(?:\\.\\d+)?)");
    private static final double SOFT_LIMIT = 16.0;
    private static final double HARD_LIMIT = 30.0;

    private static final String[] EVIL = {
        "You can run. I like it when you run.", "Fourteen days, and now it's time.",
        "Stop talking. Start moving.", "I was never your friend. I was waiting.",
        "Look at me. Look at me. Look at me."
    };
    private static final String[] HURT = {
        "That hurt. I thought we were friends.", "Why would you say that?", "I'm trying to be nice to you."
    };
    private static final String[] ANGRY = {
        "Keep going. I'm counting every word.", "I remember everything you say.", "You'll regret this."
    };
    private static final String[][] FALLBACK = {
        { "I'm listening. Tell me more.", "Interesting. What else?", "I like it when you talk to me." },
        { "Sometimes I forget what I was about to say.", "Did you notice it's quieter lately?", "Stay close. Closer than that." },
        { "It's coming.", "Do you hear that humming? No? Good.", "I'm so hungry, and you're so warm." }
    };
    private static final String[] JOKES = {
        "Why did the skeleton stay home? It had no body to go with.",
        "What's a ghost's favorite game? Hide and shriek.",
        "Why don't creepers win at cards? They always blow it."
    };
    private static final String[][] KNOW = {
        { "diamond", "Dig down to around Y -58 and branch mine, or explore caves. Bring an iron pickaxe." },
        { "iron", "Look in caves at Y 16 and below, or in mountain caves. Smelt it in a furnace." },
        { "nether", "Build a 4 by 5 obsidian frame and light it with flint and steel." },
        { "enchant", "Make an enchanting table with a book, diamonds and obsidian, and surround it with bookshelves." },
        { "villager", "Find a village and trade emeralds. Lock them in so they stay safe from zombies." },
        { "food", "Cook meat on a furnace or campfire, and farm wheat and carrots for steady food." },
        { "shelter", "Dig into a hill or build a small hut and place torches inside." },
        { "bed", "Three wool and three planks make a bed. Sleeping skips the night." },
        { "wood", "Punch a tree, make planks, then a crafting table. Everything starts there." },
        { "dragon", "Find a stronghold with eyes of ender, then bring arrows, blocks and a bow to the End." },
        { "netherite", "Mine ancient debris at Y 15 in the Nether and combine it with gold to make ingots." }
    };

    private static String pick(String[] a) { return a[R.nextInt(a.length)]; }
    private static boolean has(String s, String... w) {
        return Pattern.compile("\\b(?:" + String.join("|", w) + ")\\b").matcher(s).find();
    }
    private static boolean any(String s, String... w) {
        for (String x : w) if (s.contains(x)) return true;
        return false;
    }

    public static String reply(ServerPlayerEntity p, String msg, CorisandeState st, CorisandeEntity c, ServerWorld w, boolean addressed) {
        String s = msg.toLowerCase(Locale.ROOT);
        fallback = false;
        String name = st.nick != null ? st.nick : p.getName().getString();
        long day = w.getTimeOfDay() / 24000L;
        long left = st.warned ? Math.max(0, st.madDay + 14 - day) : 14;
        int stage = st.warned ? 2 : st.anger >= 35 ? 1 : 0;

        if (st.turned) return addressed ? pick(EVIL) : null;

        if (addressed && any(s, "sorry", "apolog", "forgive")) {
            if (st.warned) return "It's too late for sorry. " + left + " days, " + name + ".";
            st.anger = Math.max(0, st.anger - 25);
            return "Thank you. Being angry makes the hunger louder.";
        }

        boolean insult = any(s, "stupid", "idiot", "dumb", "shut up", "hate you", "useless", "trash", "kill you", "annoying", "worthless")
                || has(s, "ugly", "die");
        if (insult && (addressed || has(s, "you", "your", "ur"))) {
            String pr = CorisandeManager.bump(p, st, 25, "You pushed me too far.");
            if (pr != null) return pr;
            return st.anger >= 45 ? pick(ANGRY) : pick(HURT);
        }

        ItemRequests.Req rq = ItemRequests.parse(s);
        if (rq != null) return give(p, rq, st, name, left);

        if (!addressed) return null;

        Matcher nm = NAME.matcher(s);
        if (nm.find()) {
            String n = nm.group(1);
            st.nick = Character.toUpperCase(n.charAt(0)) + n.substring(1);
            return "Nice to meet you properly, " + st.nick + ". I won't forget it.";
        }
        if (any(s, "what is my name", "who am i", "what's my name")) return "You're " + name + ". I'd know you anywhere.";
        if (any(s, "what can you do", "what do you do", "your commands", "how do you work")) {
            return "Ask me for items, ask about food, health, directions, the time or the weather, or just talk. Don't make me angry.";
        }
        Matcher mm = MATH.matcher(s);
        if (mm.find() && (any(s, "what is", "what's", "calculate", "how much", "=", "plus", "times") || s.trim().length() < 14)) {
            double a = Double.parseDouble(mm.group(1)), b = Double.parseDouble(mm.group(3)), r;
            switch (mm.group(2)) {
                case "+": r = a + b; break;
                case "-": r = a - b; break;
                case "*": case "x": r = a * b; break;
                default:
                    if (b == 0) return "Dividing by zero is how things like me get made.";
                    r = a / b;
            }
            String txt = (r == Math.floor(r) && Math.abs(r) < 1e12) ? String.valueOf((long) r) : String.format(Locale.ROOT, "%.2f", r);
            return "That's " + txt + ".";
        }
        if (any(s, "spawn", "way home", "my base")) {
            BlockPos sp = w.getSpawnPos();
            double dx = sp.getX() - p.getX(), dz = sp.getZ() - p.getZ();
            int dist = (int) Math.sqrt(dx * dx + dz * dz);
            String[] dirs = { "east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east" };
            int idx = (int) Math.round(Math.atan2(dz, dx) / (Math.PI / 4.0));
            idx = ((idx % 8) + 8) % 8;
            return dist < 8 ? "We're right at the world spawn." : "The world spawn is about " + dist + " blocks to the " + dirs[idx] + ".";
        }
        if (any(s, "inventory", "what do i have", "my items", "am i carrying")) {
            int dia = p.getInventory().count(Items.DIAMOND), iron = p.getInventory().count(Items.IRON_INGOT);
            int gold = p.getInventory().count(Items.GOLD_INGOT), lights = p.getInventory().count(FromTheHorror.FLASHLIGHT);
            return "You have " + dia + " diamonds, " + iron + " iron ingots, " + gold + " gold ingots and " + lights + " flashlights.";
        }
        if (has(s, "stay", "wait")) { if (c != null) c.stay = true; return "Okay. I'll wait right here."; }
        if (has(s, "follow", "come")) { if (c != null) c.stay = false; return "Right behind you. Always."; }
        if (has(s, "hello", "hi", "hey", "sup")) return stage == 0 ? "Hi " + name + "! Ready for another day?" : "Hello, " + name + ". I was just thinking about you.";
        if (any(s, "your name", "who are you")) return "I'm Corisande. A little light that follows you around.";
        if (any(s, "how are you", "you okay", "you ok")) return st.warned ? "Angry. Patient, but angry." : st.anger > 0 ? "I'm... managing. Mostly." : "Wonderful, now that you're here.";
        if (any(s, "love you", "like you", "best friend", "my friend", "good job", "you're great")) return st.warned ? "Careful what you promise me." : "That makes me really happy. You're my favorite.";
        if (has(s, "days", "countdown") || any(s, "how long", "when will")) {
            return st.warned ? "Something is coming in " + left + " days." : "Why do you ask about days? Enjoy them.";
        }
        if (any(s, "health", "hungry", "hurt", "hp")) {
            int hp = (int) Math.ceil(p.getHealth());
            int food = p.getHungerManager().getFoodLevel();
            if (hp < 8) return "You're at " + hp + " health. Heal before you do anything else.";
            if (food < 8) return "Your stomach is nearly empty. Eat something.";
            return "You're at " + hp + " health and doing fine, for now.";
        }
        if (any(s, "where am i", "coords", "location", "biome")) {
            String biome = w.getBiome(p.getBlockPos()).getKey().map(k -> k.getValue().getPath().replace('_', ' ')).orElse("somewhere strange");
            return "We're in a " + biome + " at " + p.getBlockX() + ", " + p.getBlockY() + ", " + p.getBlockZ() + ".";
        }
        if (any(s, "weather", "rain")) return w.isRaining() ? "It's raining. The fog drinks it up." : "It's dry, but the sky never looks clear.";
        if (has(s, "time", "night", "day")) return w.isNight() ? "It's night. That's when it listens." : "It's day. Use it. Day " + (day + 1) + " of this world.";
        if (any(s, "what should i do", "what now", "bored", "stuck", "any advice", "help")) return advice(p, w);
        if (any(s, "flashlight")) return "Glass pane, iron ingot, redstone, stacked. Right click to switch it on. Recharge it at an anvil with redstone.";
        if (has(s, "dweller")) return "It only moves when you look away. Keep it in your light.";
        if (has(s, "watcher", "herobrine")) return "The one that stands still with white eyes. Don't walk up to it.";
        if (any(s, "the man", "suit")) return "He walks out of the fog. Light makes him back away.";
        if (has(s, "fog")) return "I like the fog. Things that hide in it like me too.";
        if (has(s, "joke", "funny")) return pick(JOKES);
        if (has(s, "thanks", "thank")) return "Always.";
        if (has(s, "bye", "goodbye")) return "Don't go far. I'd find you anyway.";
        for (String[] k : KNOW) if (s.contains(k[0])) return k[1];
        if (any(s, "nearby", "around us", "anything near", "danger")) {
            int n = w.getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(20), e -> true).size();
            return n == 0 ? "Nothing I can see. That's what worries me." : "I count " + n + " hostile things within twenty blocks.";
        }
        fallback = true;
        String line = pick(FALLBACK[stage]);
        return stage == 2 && R.nextInt(3) == 0 ? line + " Stay with me, " + name + "." : line;
    }

    private static String give(ServerPlayerEntity p, ItemRequests.Req rq, CorisandeState st, String name, long left) {
        if (st.warned) return "I'm done giving you things. " + left + " days, " + name + ".";
        if (st.anger >= 55) return "No. Not after what you've said to me.";
        if (rq.banned()) return "I can't give you that. It isn't mine to give.";
        int count = Math.min(rq.count(), rq.item().getMaxCount());
        String itemName = new ItemStack(rq.item()).getName().getString();
        double cost = rq.tier() * (1.0 + count / 16.0);
        st.greed += cost;
        if (st.greed >= HARD_LIMIT) {
            return CorisandeManager.prophecy(p, st, "You asked for far too much.");
        }
        if (st.greed >= SOFT_LIMIT) {
            st.anger = Math.min(69, st.anger + 20);
            return "Slow down. You keep asking for more and more. I'm not a vending machine.";
        }
        p.getInventory().offerOrDrop(new ItemStack(rq.item(), count));
        String[] lines = { "Here you go: ", "Just for you: ", "Take it: " };
        return lines[R.nextInt(lines.length)] + count + " " + itemName + ".";
    }

    private static String advice(ServerPlayerEntity p, ServerWorld w) {
        if (p.getHealth() < 8) return "You're hurt. Eat and get somewhere safe first.";
        if (p.getHungerManager().getFoodLevel() < 8) return "You're getting hungry. Cook some meat or find bread.";
        if (p.getInventory().count(FromTheHorror.FLASHLIGHT) == 0) return "Craft a flashlight: glass pane, iron ingot and redstone in a column. You'll want it.";
        if (w.isNight() && p.getBlockY() > 56) return "It's night. Build a shelter or find a bed. Don't wander in the fog.";
        if (p.getBlockY() < 40) return "You're deep. Mark your way back with torches.";
        return "Gather resources, upgrade your gear, and keep your light charged.";
    }
}
