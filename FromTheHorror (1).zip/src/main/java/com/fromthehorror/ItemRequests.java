package com.fromthehorror;

import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Understands messages like "give me 5 diamonds" and rates how greedy the request is. */
public final class ItemRequests {
    private ItemRequests() {}

    public record Req(Item item, int count, int tier, boolean banned) {}

    private static Map<String, Item> NAMES;
    private static final Pattern WANT = Pattern.compile(
        "\\b(give|gimme|get me|i need|i want|can i have|could i have|can i get|could i get|may i have|i would like|i'd like|id like|hand me|bring me|need|want)\\b");
    private static final Pattern NUM = Pattern.compile("\\b(\\d{1,4})\\b");

    private static void init() {
        NAMES = new HashMap<>();
        for (Item it : Registries.ITEM) {
            if (it == Items.AIR) continue;
            Identifier id = Registries.ITEM.getId(it);
            NAMES.put(id.getPath().replace('_', ' '), it);
        }
    }

    public static Req parse(String s) {
        if (!WANT.matcher(s).find()) return null;
        if (NAMES == null) init();
        String clean = " " + s.replaceAll("[^a-z0-9' ]", " ").replaceAll("\\s+", " ") + " ";
        String best = null;
        for (String n : NAMES.keySet()) {
            if (n.length() < 3) continue;
            if (clean.contains(" " + n + " ") || clean.contains(" " + n + "s ") || clean.contains(" " + n + "es ")) {
                if (best == null || n.length() > best.length()) best = n;
            }
        }
        if (best == null) return null;
        Item item = NAMES.get(best);
        int count = 1;
        Matcher m = NUM.matcher(s);
        if (m.find()) count = Integer.parseInt(m.group(1));
        else if (s.contains("stack")) count = 64;
        else if (s.contains("lots") || s.contains("tons") || s.contains("bunch") || s.contains("many")) count = 32;
        String path = Registries.ITEM.getId(item).getPath();
        return new Req(item, Math.max(1, count), tier(path), banned(path));
    }

    /** 12 = very rare, 5 = rare, 2 = uncommon, 1 = common. */
    private static int tier(String p) {
        if (p.startsWith("netherite") || p.equals("elytra") || p.equals("nether_star") || p.equals("beacon")
                || p.equals("totem_of_undying") || p.equals("enchanted_golden_apple") || p.equals("trident")
                || p.equals("heart_of_the_sea") || p.equals("shulker_shell") || p.equals("end_crystal")
                || p.equals("conduit") || p.equals("dragon_head") || p.equals("wither_skeleton_skull")) return 12;
        if (p.startsWith("diamond") || p.startsWith("emerald") || p.equals("ancient_debris") || p.equals("golden_apple")
                || p.equals("ender_pearl") || p.equals("ender_eye") || p.equals("blaze_rod") || p.equals("experience_bottle")
                || p.contains("shulker_box") || p.equals("enchanted_book") || p.contains("music_disc") || p.equals("saddle")
                || p.equals("name_tag")) return 5;
        if (p.startsWith("iron") || p.startsWith("gold") || p.equals("redstone") || p.equals("lapis_lazuli")
                || p.equals("bow") || p.equals("crossbow") || p.equals("shield") || p.equals("anvil")
                || p.equals("enchanting_table") || p.equals("tnt") || p.equals("ender_chest")) return 2;
        return 1;
    }

    private static boolean banned(String p) {
        return p.contains("command_block") || p.equals("bedrock") || p.equals("barrier") || p.equals("spawner")
                || p.contains("structure") || p.equals("jigsaw") || p.equals("debug_stick") || p.equals("dragon_egg")
                || p.equals("light") || p.equals("knowledge_book") || p.contains("spawn_egg")
                || p.equals("end_portal_frame") || p.equals("reinforced_deepslate") || p.equals("petrified_oak_slab");
    }
}
