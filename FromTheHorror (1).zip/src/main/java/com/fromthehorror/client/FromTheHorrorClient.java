package com.fromthehorror.client;

import com.fromthehorror.FromTheHorror;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

public class FromTheHorrorClient implements ClientModInitializer {
    private static boolean voice = true;

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(NfLayers.DWELLER, () -> Layers.dweller());
        EntityModelLayerRegistry.registerModelLayer(NfLayers.WATCHER, () -> Layers.watcher());
        EntityModelLayerRegistry.registerModelLayer(NfLayers.MAN, () -> Layers.man());
        EntityModelLayerRegistry.registerModelLayer(NfLayers.ORB, OrbModel::build);

        EntityRendererRegistry.register(FromTheHorror.DWELLER, ctx -> new FigureRenderer<>(ctx, NfLayers.DWELLER, FigureModel.DWELLER, "dweller", 1.3f));
        EntityRendererRegistry.register(FromTheHorror.WATCHER, ctx -> new FigureRenderer<>(ctx, NfLayers.WATCHER, FigureModel.WATCHER, "watcher", 1.0f));
        EntityRendererRegistry.register(FromTheHorror.MAN, ctx -> new FigureRenderer<>(ctx, NfLayers.MAN, FigureModel.MAN, "man_from_the_fog", 0.9f));
        EntityRendererRegistry.register(FromTheHorror.CORISANDE, CorisandeRenderer::new);

        // Fog closes in when the Man from the Fog is near.
        ClientTickEvents.END_CLIENT_TICK.register(client -> FogState.tick(client));

        // Speak Corisande's chat lines aloud with the system voice. Her angry lines are slower and lower.
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            String s = message.getString();
            if (voice && s.startsWith("<Corisande> ")) {
                TextColor c = message.getStyle().getColor();
                Integer evilRgb = Formatting.DARK_RED.getColorValue();
                boolean evil = c != null && evilRgb != null && c.getRgb() == evilRgb;
                Tts.speak(s.substring(12), evil);
            }
        });

        // She hears you from the moment you join (Windows). /corilisten off to stop.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> VoiceListener.start(client, true));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> VoiceListener.stop());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> VoiceListener.stop());

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("corivoice")
                .then(ClientCommandManager.literal("on").executes(c -> {
                    voice = true; c.getSource().sendFeedback(Text.literal("Corisande's voice is on.")); return 1; }))
                .then(ClientCommandManager.literal("off").executes(c -> {
                    voice = false; c.getSource().sendFeedback(Text.literal("Corisande's voice is off.")); return 1; })));
            dispatcher.register(ClientCommandManager.literal("corilisten")
                .then(ClientCommandManager.literal("on").executes(c -> {
                    VoiceListener.start(MinecraftClient.getInstance(), false); return 1; }))
                .then(ClientCommandManager.literal("off").executes(c -> {
                    VoiceListener.stop(); c.getSource().sendFeedback(Text.literal("Corisande stopped listening.")); return 1; })));
        });
    }
}
