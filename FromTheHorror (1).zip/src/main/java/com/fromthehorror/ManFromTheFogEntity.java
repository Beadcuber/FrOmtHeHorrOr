package com.fromthehorror;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** The Man from the Fog: a tall pale figure in a suit and hat. Walks slowly out of the fog. A flashlight stare makes him retreat. */
public class ManFromTheFogEntity extends HostileEntity {
    private int life = 20 * 120;
    private int recoil = 0;

    public ManFromTheFogEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0);
    }

    @Override
    public void tick() {
        super.tick();
        World w = this.getWorld();
        if (w.isClient) return;
        if (--life <= 0) { vanish(); return; }
        PlayerEntity p = w.getClosestPlayer(this, 64.0);
        if (p == null || p.isSpectator()) {
            if (this.age > 600) vanish();
            return;
        }
        double d = this.distanceTo(p);
        if (this.age % 8 == 0 && w instanceof ServerWorld fogWorld) {
            fogWorld.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 0.3, getZ(), 3, 0.5, 0.15, 0.5, 0.01);
        }
        boolean seen = Sight.looking(p, this, 0.95);
        if (seen && Sight.flashlightOn(p)) {
            Vec3d away = this.getPos().subtract(p.getPos()).normalize().multiply(10).add(this.getPos());
            this.getNavigation().startMovingTo(away.x, away.y, away.z, 1.4);
            if (++recoil > 100) { vanish(); return; }
        } else {
            this.getNavigation().startMovingTo(p, 0.95);
        }
        if (d < 2.0 && this.age % 20 == 0) {
            this.tryAttack(p);
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
            vanish();
            return;
        }
        if (this.age % 60 == 0 && d < 32) {
            w.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_AMBIENT, SoundCategory.HOSTILE, 1.0f, 0.5f);
        }
    }

    private void vanish() {
        if (this.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 25, 0.3, 0.8, 0.3, 0.02);
        }
        this.discard();
    }
}
