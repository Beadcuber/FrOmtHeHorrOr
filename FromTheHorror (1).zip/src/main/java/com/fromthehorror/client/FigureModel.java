package com.fromthehorror.client;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Shared animation for the tall custom bodies (Dweller, Watcher, Man from the Fog).
 * The shapes themselves live in {@link Layers}; this class only moves head, arms and legs.
 */
public class FigureModel<T extends HostileEntity> extends EntityModel<T> {
    /** hipY/bodyH come from the layer. hunch tips the torso forward. */
    public record Spec(float hipY, float bodyH, float armDrop, float hunch, float armForward, float armSwing, float sway) {}

    public static final Spec DWELLER = new Spec(11f, 11f, 1.5f, 0.45f, 0.25f, 0.9f, 0.05f);
    public static final Spec WATCHER = new Spec(9f, 14f, 1.0f, 0.0f, 0.0f, 0.15f, 0.015f);
    public static final Spec MAN = new Spec(9f, 14f, 1.0f, 0.04f, 0.0f, 0.35f, 0.03f);

    private final ModelPart root, head, body, rArm, lArm, rLeg, lLeg;
    private final Spec s;

    public FigureModel(ModelPart root, Spec s) {
        this.root = root;
        this.s = s;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rArm = root.getChild("right_arm");
        this.lArm = root.getChild("left_arm");
        this.rLeg = root.getChild("right_leg");
        this.lLeg = root.getChild("left_leg");
    }

    @Override
    public void setAngles(T e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        float neckY = s.hipY() - s.bodyH() * MathHelper.cos(s.hunch());
        float neckZ = -s.bodyH() * MathHelper.sin(s.hunch());
        body.pitch = s.hunch();
        head.pivotY = neckY;
        head.pivotZ = neckZ;
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f - s.hunch() * 0.6f;
        rArm.pivotY = neckY + s.armDrop();
        lArm.pivotY = rArm.pivotY;
        rArm.pivotZ = neckZ;
        lArm.pivotZ = neckZ;
        float sw = MathHelper.cos(limbAngle * 0.6662f) * limbDistance;
        rLeg.pitch = sw * 1.2f;
        lLeg.pitch = -sw * 1.2f;
        rArm.pitch = -sw * s.armSwing() + s.armForward();
        lArm.pitch = sw * s.armSwing() + s.armForward();
        float sway = MathHelper.sin(anim * 0.07f) * s.sway();
        rArm.roll = 0.05f + sway;
        lArm.roll = -0.05f - sway;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float r, float g, float b, float a) {
        root.render(matrices, vertices, light, overlay, r, g, b, a);
    }
}
