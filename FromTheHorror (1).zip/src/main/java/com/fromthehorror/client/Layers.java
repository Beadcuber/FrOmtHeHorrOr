package com.fromthehorror.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/** Generated model layers. Every box here has a matching painted region in the entity textures. */
public final class Layers {
    private Layers() {}

    public static TexturedModelData dweller() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_head = root.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-2.5f, -5f, -2.5f, 5f, 5f, 5f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_jaw = p_head.addChild("jaw", ModelPartBuilder.create().uv(0, 10).cuboid(-2.5f, 0f, -5f, 5f, 3f, 5f), ModelTransform.of(0f, -1f, 2.5f, 0.5f, 0f, 0f));
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 20).cuboid(-3.5f, -11f, -2f, 7f, 11f, 4f), ModelTransform.of(0f, 11f, 0f, 0f, 0f, 0f));
        ModelPartData p_spines = p_body.addChild("spines", ModelPartBuilder.create().uv(24, 20).cuboid(-0.5f, -10f, 2f, 1f, 2f, 2f).uv(24, 20).cuboid(-0.5f, -7f, 2f, 1f, 2f, 2f).uv(24, 20).cuboid(-0.5f, -4f, 2f, 1f, 2f, 2f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_arm = root.addChild("right_arm", ModelPartBuilder.create().uv(28, 0).cuboid(-1f, 0f, -1f, 2f, 22f, 2f), ModelTransform.of(-4.5f, 1.5f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_arm = root.addChild("left_arm", ModelPartBuilder.create().uv(36, 0).cuboid(-1f, 0f, -1f, 2f, 22f, 2f), ModelTransform.of(4.5f, 1.5f, 0f, 0f, 0f, 0f));
        ModelPartData p_r_hand = p_right_arm.addChild("r_hand", ModelPartBuilder.create().uv(44, 0).cuboid(-1.5f, 22f, -1.5f, 3f, 3f, 3f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_l_hand = p_left_arm.addChild("l_hand", ModelPartBuilder.create().uv(44, 0).cuboid(-1.5f, 22f, -1.5f, 3f, 3f, 3f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_r_claws = p_right_arm.addChild("r_claws", ModelPartBuilder.create().uv(44, 6).cuboid(-1.5f, 25f, -1.5f, 1f, 3f, 1f).uv(44, 6).cuboid(0.5f, 25f, -1.5f, 1f, 3f, 1f).uv(44, 6).cuboid(-0.5f, 25f, 0.5f, 1f, 3f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_l_claws = p_left_arm.addChild("l_claws", ModelPartBuilder.create().uv(44, 6).cuboid(-1.5f, 25f, -1.5f, 1f, 3f, 1f).uv(44, 6).cuboid(0.5f, 25f, -1.5f, 1f, 3f, 1f).uv(44, 6).cuboid(-0.5f, 25f, 0.5f, 1f, 3f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_leg = root.addChild("right_leg", ModelPartBuilder.create().uv(0, 36).cuboid(-1.5f, 0f, -1.5f, 3f, 13f, 3f), ModelTransform.of(-2.5f, 11f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_leg = root.addChild("left_leg", ModelPartBuilder.create().uv(12, 36).cuboid(-1.5f, 0f, -1.5f, 3f, 13f, 3f), ModelTransform.of(2.5f, 11f, 0f, 0f, 0f, 0f));
        ModelPartData p_r_toes = p_right_leg.addChild("r_toes", ModelPartBuilder.create().uv(24, 36).cuboid(-1.5f, 12f, -3.5f, 3f, 1f, 2f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_l_toes = p_left_leg.addChild("l_toes", ModelPartBuilder.create().uv(24, 36).cuboid(-1.5f, 12f, -3.5f, 3f, 1f, 2f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

    public static TexturedModelData watcher() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_head = root.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-3f, -7f, -3f, 6f, 7f, 6f), ModelTransform.of(0f, -5f, 0f, 0f, 0f, 0f));
        ModelPartData p_horns = p_head.addChild("horns", ModelPartBuilder.create().uv(40, 10).cuboid(-2.5f, -10f, -0.5f, 1f, 3f, 1f).uv(40, 10).cuboid(1.5f, -10f, -0.5f, 1f, 3f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 16).cuboid(-2.5f, -14f, -1.5f, 5f, 14f, 3f), ModelTransform.of(0f, 9f, 0f, 0f, 0f, 0f));
        ModelPartData p_coat = p_body.addChild("coat", ModelPartBuilder.create().uv(0, 34).cuboid(-3f, -13f, 1.5f, 6f, 13f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_arm = root.addChild("right_arm", ModelPartBuilder.create().uv(28, 0).cuboid(-1f, 0f, -1f, 2f, 20f, 2f), ModelTransform.of(-3.5f, -4f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_arm = root.addChild("left_arm", ModelPartBuilder.create().uv(36, 0).cuboid(-1f, 0f, -1f, 2f, 20f, 2f), ModelTransform.of(3.5f, -4f, 0f, 0f, 0f, 0f));
        ModelPartData p_r_fingers = p_right_arm.addChild("r_fingers", ModelPartBuilder.create().uv(44, 0).cuboid(-1f, 20f, -1f, 2f, 4f, 2f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_l_fingers = p_left_arm.addChild("l_fingers", ModelPartBuilder.create().uv(44, 0).cuboid(-1f, 20f, -1f, 2f, 4f, 2f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_leg = root.addChild("right_leg", ModelPartBuilder.create().uv(20, 34).cuboid(-1f, 0f, -1f, 2f, 15f, 2f), ModelTransform.of(-1.5f, 9f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_leg = root.addChild("left_leg", ModelPartBuilder.create().uv(28, 34).cuboid(-1f, 0f, -1f, 2f, 15f, 2f), ModelTransform.of(1.5f, 9f, 0f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

    public static TexturedModelData man() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_head = root.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-3f, -8f, -3f, 6f, 8f, 6f), ModelTransform.of(0f, -5f, 0f, 0f, 0f, 0f));
        ModelPartData p_brim = p_head.addChild("brim", ModelPartBuilder.create().uv(0, 14).cuboid(-5f, -9f, -5f, 10f, 1f, 10f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_crown = p_head.addChild("crown", ModelPartBuilder.create().uv(0, 26).cuboid(-3f, -13f, -3f, 6f, 4f, 6f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 36).cuboid(-4f, -14f, -2f, 8f, 14f, 4f), ModelTransform.of(0f, 9f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_arm = root.addChild("right_arm", ModelPartBuilder.create().uv(40, 0).cuboid(-1.5f, 0f, -1.5f, 3f, 19f, 3f), ModelTransform.of(-5.5f, -4f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_arm = root.addChild("left_arm", ModelPartBuilder.create().uv(52, 0).cuboid(-1.5f, 0f, -1.5f, 3f, 19f, 3f), ModelTransform.of(5.5f, -4f, 0f, 0f, 0f, 0f));
        ModelPartData p_r_hand = p_right_arm.addChild("r_hand", ModelPartBuilder.create().uv(40, 22).cuboid(-1.5f, 19f, -1.5f, 3f, 3f, 3f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_l_hand = p_left_arm.addChild("l_hand", ModelPartBuilder.create().uv(40, 22).cuboid(-1.5f, 19f, -1.5f, 3f, 3f, 3f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_r_fingers = p_right_arm.addChild("r_fingers", ModelPartBuilder.create().uv(52, 22).cuboid(-1.5f, 22f, -1.5f, 1f, 4f, 1f).uv(52, 22).cuboid(0.5f, 22f, -1.5f, 1f, 4f, 1f).uv(52, 22).cuboid(-0.5f, 22f, 0.5f, 1f, 4f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_l_fingers = p_left_arm.addChild("l_fingers", ModelPartBuilder.create().uv(52, 22).cuboid(-1.5f, 22f, -1.5f, 1f, 4f, 1f).uv(52, 22).cuboid(0.5f, 22f, -1.5f, 1f, 4f, 1f).uv(52, 22).cuboid(-0.5f, 22f, 0.5f, 1f, 4f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_leg = root.addChild("right_leg", ModelPartBuilder.create().uv(28, 36).cuboid(-2f, 0f, -2f, 4f, 15f, 4f), ModelTransform.of(-2f, 9f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_leg = root.addChild("left_leg", ModelPartBuilder.create().uv(44, 36).cuboid(-2f, 0f, -2f, 4f, 15f, 4f), ModelTransform.of(2f, 9f, 0f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

    public static TexturedModelData orb() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -4f, -4f, 8f, 8f, 8f).uv(0, 16).cuboid(-3f, -5f, -3f, 6f, 10f, 6f).uv(24, 16).cuboid(-5f, -3f, -3f, 10f, 6f, 6f), ModelTransform.of(0f, 16f, 0f, 0f, 0f, 0f));
        ModelPartData p_tuft = p_body.addChild("tuft", ModelPartBuilder.create().uv(0, 32).cuboid(-1f, -8f, -1f, 2f, 3f, 2f).uv(8, 32).cuboid(-0.5f, -10f, -0.5f, 1f, 2f, 1f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_spikes = p_body.addChild("spikes", ModelPartBuilder.create().uv(0, 40).cuboid(-1f, -10f, -1f, 2f, 5f, 2f).uv(0, 40).cuboid(-1f, 5f, -1f, 2f, 5f, 2f).uv(8, 40).cuboid(-10f, -1f, -1f, 5f, 2f, 2f).uv(8, 40).cuboid(5f, -1f, -1f, 5f, 2f, 2f).uv(24, 40).cuboid(-1f, -1f, -10f, 2f, 2f, 5f).uv(24, 40).cuboid(-1f, -1f, 5f, 2f, 2f, 5f), ModelTransform.of(0f, 0f, 0f, 0f, 0f, 0f));
        ModelPartData p_right_arm = p_body.addChild("right_arm", ModelPartBuilder.create().uv(40, 40).cuboid(-1f, 0f, -1f, 2f, 16f, 2f), ModelTransform.of(-6f, 2f, 0f, 0f, 0f, 0f));
        ModelPartData p_left_arm = p_body.addChild("left_arm", ModelPartBuilder.create().uv(40, 40).cuboid(-1f, 0f, -1f, 2f, 16f, 2f), ModelTransform.of(6f, 2f, 0f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

}
