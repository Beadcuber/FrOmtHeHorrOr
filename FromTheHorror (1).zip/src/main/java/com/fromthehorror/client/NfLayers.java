package com.fromthehorror.client;

import com.fromthehorror.FromTheHorror;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public final class NfLayers {
    private NfLayers() {}
    public static final EntityModelLayer DWELLER = new EntityModelLayer(new Identifier(FromTheHorror.ID, "dweller"), "main");
    public static final EntityModelLayer WATCHER = new EntityModelLayer(new Identifier(FromTheHorror.ID, "watcher"), "main");
    public static final EntityModelLayer MAN = new EntityModelLayer(new Identifier(FromTheHorror.ID, "man"), "main");
    public static final EntityModelLayer ORB = new EntityModelLayer(new Identifier(FromTheHorror.ID, "orb"), "main");
}
