package com.fromthehorror;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/fromthehorror.json. Leave apiKey empty to use Corisande's built-in brain only. */
public final class Config {
    /** Optional: an Anthropic API key makes Corisande answer free-form questions with a real language model. */
    public String apiKey = "";
    public String model = "claude-haiku-5-5";
    public String endpoint = "https://api.anthropic.com/v1/messages";

    private static Config instance;

    public static synchronized Config get() {
        if (instance != null) return instance;
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("fromthehorror.json");
        Config c = new Config();
        try {
            if (Files.exists(file)) {
                Config read = gson.fromJson(Files.readString(file, StandardCharsets.UTF_8), Config.class);
                if (read != null) c = read;
            } else {
                Files.createDirectories(file.getParent());
                Files.writeString(file, gson.toJson(c), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) {
            // Bad or unreadable config: fall back to defaults.
        }
        if (c.apiKey == null) c.apiKey = "";
        if (c.model == null || c.model.isBlank()) c.model = "claude-haiku-5-5";
        if (c.endpoint == null || c.endpoint.isBlank()) c.endpoint = "https://api.anthropic.com/v1/messages";
        instance = c;
        return c;
    }
}
